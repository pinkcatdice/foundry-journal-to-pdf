// Хук, который срабатывает при запуске Foundry VTT
Hooks.once("init", async function () {
  console.log("Journal to PDF Exporter | Initializing module...");
});

// Хук для добавления кнопки "Export to PDF" в интерфейс журнала
Hooks.on("renderJournalSheet", (app, html, data) => {
  // Создаем кнопку
  const exportButton = $(`<button class="export-to-pdf">Export to PDF</button>`);

  // Добавляем обработчик клика для кнопки
  exportButton.on("click", () => exportJournalToPDF(app));

  // Добавляем кнопку в заголовок журнала
  html.closest('.window-content').find('.header-buttons').append(exportButton);
});

// Функция для экспорта журнала в PDF
async function exportJournalToPDF(app) {
  // Загружаем библиотеку jsPDF
  const { jsPDF } = window.jspdf;

  // Создаем новый PDF-документ
  const doc = new jsPDF();

  // Получаем заголовок и содержимое журнала
  const title = app.document.name || "Journal";
  const content = app.document.content || "No content";

  // Добавляем заголовок
  doc.setFontSize(18);
  doc.text(title, 10, 10);

  // Добавляем содержимое (с учётом многострочности)
  doc.setFontSize(12);
  const lines = doc.splitTextToSize(content, 180); // Разделяем текст по ширине страницы
  doc.text(lines, 10, 20);

  // Сохраняем PDF
  doc.save(`${title}.pdf`);
}
